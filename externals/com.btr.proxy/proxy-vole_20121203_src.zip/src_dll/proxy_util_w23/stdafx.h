// stdafx.h : Includefiles for Standardsystem-Includefiles

#pragma once

#include "targetver.h"

#define WIN32_LEAN_AND_MEAN  // No not include rarely used parts of Windows-Header .
// Windows-Headerfiles:
#include <windows.h>
#include <winhttp.h>
#include <Winreg.h>