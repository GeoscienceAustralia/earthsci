/*
 * %W% %E%
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef RAWWINVER_H
#define RAWWINVER_H

#define _WIN32_WINNT 0x0501
#define WINVER 0x0501

#endif
