package de.fruitfly.ovr;

public class SensorInfo {
	// Not implemented yet
}
